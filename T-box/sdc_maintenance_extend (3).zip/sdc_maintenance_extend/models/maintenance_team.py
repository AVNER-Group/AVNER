from odoo import models, fields, api
import datetime as dt
import datetime

class MaintenanceTeam(models.Model):
    _inherit = 'maintenance.team'
    _description = 'Maintenance Teams'

    todo_request_count_done = fields.Integer(string="Number of Requests Done", compute='compute_todo_maintenance_requests')
    todo_request_count_exceeded = fields.Integer(string="Number of Requests Exceeded", compute='compute_todo_maintenance_requests')

    
    todo_request_count_date_7_days = fields.Integer(string="Number of Requests Scheduled", compute='compute_todo_maintenance_requests')
    todo_request_count_high_priority_7_days = fields.Integer(string="Number of Requests in High Priority", compute='compute_todo_maintenance_requests')
    todo_request_count_block_7_days = fields.Integer(string="Number of Requests Blocked", compute='compute_todo_maintenance_requests')
    todo_request_count_unscheduled_7_days = fields.Integer(string="Number of Requests Unscheduled", compute='compute_todo_maintenance_requests')
    todo_request_count_done_7_days = fields.Integer(string="Number of Requests Done", compute='compute_todo_maintenance_requests')
    todo_request_count_exceeded_7_days = fields.Integer(string="Number of Requests Exceeded", compute='compute_todo_maintenance_requests')

    todo_request_count_date_30_days = fields.Integer(string="Number of Requests Scheduled", compute='compute_todo_maintenance_requests')
    todo_request_count_high_priority_30_days = fields.Integer(string="Number of Requests in High Priority", compute='compute_todo_maintenance_requests')
    todo_request_count_block_30_days = fields.Integer(string="Number of Requests Blocked", compute='compute_todo_maintenance_requests')
    todo_request_count_unscheduled_30_days = fields.Integer(string="Number of Requests Unscheduled", compute='compute_todo_maintenance_requests')
    todo_request_count_done_30_days = fields.Integer(string="Number of Requests Done", compute='compute_todo_maintenance_requests')
    todo_request_count_exceeded_30_days = fields.Integer(string="Number of Requests Exceeded", compute='compute_todo_maintenance_requests')

    
    @api.model
    @api.depends('request_ids.stage_id','request_ids.state')
    def compute_todo_maintenance_requests(self):
        for team in self:
            after_seven_date = datetime.date.today() - datetime.timedelta(days=7)
            team.todo_request_count_date_7_days = len(team.todo_request_ids.filtered(lambda e: e.schedule_date != False and e.request_date <= datetime.date.today() and e.request_date >= after_seven_date))
            team.todo_request_count_high_priority_7_days = len(team.todo_request_ids.filtered(lambda e: e.priority == '3' and e.request_date <= datetime.date.today() and e.request_date >= after_seven_date))
            team.todo_request_count_block_7_days = len(team.todo_request_ids.filtered(lambda e: e.kanban_state == 'blocked' and e.request_date <= datetime.date.today() and e.request_date >= after_seven_date))
            team.todo_request_count_unscheduled_7_days = len(team.todo_request_ids.filtered(lambda e: not e.schedule_date and e.request_date <= datetime.date.today() and e.request_date >= after_seven_date))
            team.todo_request_count_done_7_days = len(team.request_ids.filtered(lambda e: e.stage_id.done==True and e.request_date <= datetime.date.today() and e.request_date >= after_seven_date))
            team.todo_request_count_exceeded_7_days = len(team.request_ids.filtered(lambda e: e.stage_id.is_exceeded==True and e.request_date <= datetime.date.today() and e.request_date >= after_seven_date))

            after_thirty_date = datetime.date.today() - datetime.timedelta(days=30)
            team.todo_request_count_date_30_days = len(team.todo_request_ids.filtered(lambda e: e.schedule_date != False and e.request_date <= datetime.date.today() and e.request_date >= after_thirty_date))
            team.todo_request_count_high_priority_30_days = len(team.todo_request_ids.filtered(lambda e: e.priority == '3' and e.request_date <= datetime.date.today() and e.request_date >= after_thirty_date))
            team.todo_request_count_block_30_days = len(team.todo_request_ids.filtered(lambda e: e.kanban_state == 'blocked' and e.request_date <= datetime.date.today() and e.request_date >= after_thirty_date))
            team.todo_request_count_unscheduled_30_days = len(team.todo_request_ids.filtered(lambda e: not e.schedule_date and e.request_date <= datetime.date.today() and e.request_date >= after_thirty_date))
            team.todo_request_count_done_30_days = len(team.request_ids.filtered(lambda e: e.stage_id.done==True and e.request_date <= datetime.date.today() and e.request_date >= after_thirty_date))
            team.todo_request_count_exceeded_30_days = len(team.request_ids.filtered(lambda e: e.stage_id.is_exceeded==True and e.request_date <= datetime.date.today() and e.request_date >= after_thirty_date))

            team.todo_request_count_done = len(team.request_ids.filtered(lambda e: e.stage_id.done==True))
            team.todo_request_count_exceeded = len(team.request_ids.filtered(lambda e: e.stage_id.is_exceeded==True))


class MaintenanceStage(models.Model):
    _inherit = 'maintenance.stage'
    
    is_exceeded = fields.Boolean(string="Request Exceeded")