from ast import literal_eval
from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    days_interval = fields.Integer(u'Interval (days) For Email')
    
    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        config_param = self.env['ir.config_parameter'].sudo()
        days_interval = config_param.get_param('sdc_maintenance_extend.days_interval')
        res.update(
            days_interval=int(config_param.get_param('days_interval')),
        )
        return res

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        config_param = self.env['ir.config_parameter'].sudo()
        config_param.sudo().set_param('days_interval', self.days_interval)
        