# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import datetime as dt
import datetime


class MaintenanceRequest(models.AbstractModel):
	_inherit = 'maintenance.request'

	@api.onchange("stage_id")
	def onchange_stage_id(self):
		if self.stage_id.done:
			self.days_last_done = fields.Date.today()


	def _get_state(self):
		for record in self:
			if record.meter == u'days':
				if record.days_left <= 0:
					record.state = u'Exceeded'
					record.is_exceeded = True
				elif record.days_left <= record.days_warn_period:
					record.state = u'Approached'
				else:
					record.state = u'OK'
			return True
		

	is_primary_request = fields.Boolean(copy=False)
	maintenance_request = fields.Many2one('maintenance.request')
	is_exceeded = fields.Boolean()
	# state = fields.Char(compute='_get_state', string='Status', track_visibility='always',store=True)

	@api.onchange("stage_id")
	def onchange_stage_id(self):
		if self.stage_id.done:
			self.days_last_done = fields.Date.today()

	def write(self, vals):
		if vals.get('is_exceeded'):
			stage_exceeded_id = self.env['maintenance.stage'].search([('is_exceeded','=',True)])
			if stage_exceeded_id:
				vals.update({'stage_id' : stage_exceeded_id.id})
		return super(MaintenanceRequest, self).write(vals)

	def create_new_maintenance_request(self):
		maintenance_request_ids = self.search([('is_primary_request','=',False),('stage_id.done','=',True),('maintenance_type','!=','corrective')])
		print(maintenance_request_ids)
		for maintenance_request_id in maintenance_request_ids:
			if maintenance_request_id.days_left == maintenance_request_id.days_warn_period:
				new_request = maintenance_request_id.copy(default={
					'maintenance_request':maintenance_request_id.id,
					'schedule_date': maintenance_request_id.days_next_due,})
				maintenance_request_id.is_primary_request = True

	@api.model
	def get_request_data_custom(self, start_date, end_date):
		if start_date and end_date:
			request_ids = self.env['maintenance.request'].search(
			[('request_date', '<=', str(end_date)),
			('request_date', '>=', str(start_date)),
			('maintenance_type','=','preventive')])

			action = self.env.ref('sdc_maintenance.hr_equipment_request_action_pm').read()[0]
			action['domain'] = [('id', 'in', request_ids.ids)]
			return request_ids.ids

	@api.model
	def get_request_data_custom_last_seven(self):
		after_seven_date = datetime.date.today() - datetime.timedelta(days=7)
		request_ids = self.env['maintenance.request'].search(
		[('request_date', '<=', datetime.date.today()),
		('request_date', '>=', after_seven_date),
		('maintenance_type','=','preventive')])
		return request_ids.ids

	@api.model
	def get_request_data_custom_last_seven(self):
		after_seven_date = datetime.date.today() - datetime.timedelta(days=7)
		request_ids = self.env['maintenance.request'].search(
		[('request_date', '<=', datetime.date.today()),
		('request_date', '>=', after_seven_date),
		('maintenance_type','=','preventive')])
		return request_ids.ids

	@api.model
	def get_request_data_custom_last_thirty(self):
		after_thirty_date = datetime.date.today() - datetime.timedelta(days=30)
		request_ids = self.env['maintenance.request'].search(
		[('request_date', '<=', datetime.date.today()),
		('request_date', '>=', after_thirty_date),
		('maintenance_type','=','preventive')])
		return request_ids.ids

	
	def activity_update(self):
		days_interval = int(self.env['ir.config_parameter'].sudo().get_param('days_interval'))
		if days_interval >= self.days_interval:
			self.filtered(lambda request: not request.schedule_date).activity_unlink(['maintenance.mail_act_maintenance_request'])
			for request in self.filtered(lambda request: request.schedule_date):
				date_dl = fields.Datetime.from_string(request.schedule_date).date()
				updated = request.activity_reschedule(
				['maintenance.mail_act_maintenance_request'],
				date_deadline=date_dl,
				new_user_id=request.user_id.id or request.owner_user_id.id or self.env.uid)
				if not updated:
					if request.equipment_id:
						note = _('Request planned for <a href="#" data-oe-model="%s" data-oe-id="%s">%s</a>') % (
						request.equipment_id._name, request.equipment_id.id, request.equipment_id.display_name)
					else:
						note = False
					request.activity_schedule(
					'maintenance.mail_act_maintenance_request',
					fields.Datetime.from_string(request.schedule_date).date(),
					note=note, user_id=request.user_id.id or request.owner_user_id.id or self.env.uid)