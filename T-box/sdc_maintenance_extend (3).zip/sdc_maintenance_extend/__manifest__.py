# -*- coding: utf-8 -*-
{
    'name': "OMaintenance Extend",

    'summary': """
        This Module allow you to Extend OMaintenance Feature.""",

    'description': """
        OMaintenance Extend.
        This Module allow you to Extend OMaintenance Feature.
    """,

    'author': "Nancy Nesline",
    'website': "",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Specific module',
    'version': '1.0.13.0',

    # any module necessary for this one to work correctly
    'depends': ['sdc_maintenance','maintenance'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'data/cron.xml',
        'views/views.xml',
        'views/config_settings_views.xml',
        # 'views/templates.xml',
    ],

    # 'qweb': ['static/src/xml/*.xml'],
}
