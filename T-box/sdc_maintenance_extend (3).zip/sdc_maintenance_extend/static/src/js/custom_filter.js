odoo.define('sdc_maintenance_extend.custom_filter', function (require) {
    "use strict";

    var core = require('web.core');

    var KanbanController = require("web.KanbanController");

    KanbanController.include({

        renderButtons: function() {

        this._super.apply(this, arguments);

            if (this.$buttons) {

                let filter_button = this.$buttons.find('.oe_custom_filter_button');
                let filter_button_last_seven = this.$buttons.find('.oe_custom_filter_button_last_seven');
                let filter_button_last_thirty = this.$buttons.find('.oe_custom_filter_button_last_thirty');

                filter_button && filter_button.click(this.proxy('filter_button')) ;
                filter_button_last_seven && filter_button_last_seven.click(this.proxy('filter_button_last_seven')) ;
                filter_button_last_thirty && filter_button_last_thirty.click(this.proxy('filter_button_last_thirty')) ;

            }

        },

        filter_button: function () {

            this._rpc({
                model: 'maintenance.team',
                method: 'compute_todo_maintenance_requests',
                
            }).then(result => {
                // var domain = [['id', 'in', result]]

                
            });
        },

        filter_button_last_seven: function () {
            this._rpc({
                model: 'maintenance.request',
                method: 'get_request_data_custom_last_seven',
            }).then(result => {
                var domain = [['id', 'in', result]]

                this.do_action({
                    type: 'ir.actions.act_window',
                    name: 'Maintenance Preventive',
                    views: [[false, 'list']],
                    res_model: 'maintenance.request',
                    domain:domain,
                });
            });
        },

        filter_button_last_thirty: function () {
            this._rpc({
                model: 'maintenance.request',
                method: 'get_request_data_custom_last_thirty',
            }).then(result => {
                var domain = [['id', 'in', result]]

                this.do_action({
                    type: 'ir.actions.act_window',
                    name: 'Maintenance Preventive',
                    views: [[false, 'list']],
                    res_model: 'maintenance.request',
                    domain:domain,
                });
            });
        }
    });

})