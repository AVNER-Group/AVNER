# ©  2008-2021 Deltatech
# See README.rst file on addons root folder for license details

from . import sale_margin_report
