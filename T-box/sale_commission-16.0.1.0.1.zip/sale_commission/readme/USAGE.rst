For adding commissions on sales orders:

#. Go to *Sales > Orders > Quotations*.
#. Edit or create a new record.
#. When you have selected a partner, each new quotation line you add will have
   the agents and commissions set at customer level.
#. You can add, modify or delete these agents discretely clicking on the
   icon with several persons represented, next to the "Commission" field in the
   list. This icon will be available only if the line hasn't been invoiced yet.
#. If you have configured your system for editing lines in a popup window,
   agents will appear also in this window.
#. You have a button "Regenerate agents" on the bottom of the page
   "Order Lines" for forcing a recompute of all agents from the partner setup.
   This is needed for example when you have changed the partner on the
   quotation having already inserted lines.
