* Pexego.
* Davide Corio <davide.corio@domsense.com>
* Joao Alfredo Gama Batista <joao.gama@savoirfairelinux.com>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Giorgio Borelli <giorgio.borelli@abstract.it>
* Daniel Campos <danielcampos@avanzosc.es>
* Oihane Crucelaegui <oihanecruce@gmail.com>
* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>

* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Manuel Calero

* `Quartile <https://www.quartile.co>`__:

  * Aung Ko Ko Lin
  * Yoshi Tashiro

* `Studio73 <https://www.studio73.es>`__:

  * Ethan Hildick
