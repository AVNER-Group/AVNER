##############################################################################
#
#    Copyright (C) 2022-Present Speeduplight (<https://speeduplight.com>)
#
##############################################################################
{
    'name': 'CRM Integration',
    'version': '16.0.1.0.0',
    'sequence': -10,
    'category': 'CRM',
    'author': 'Speeduplight',
    'description': """Common CRM Information, India Mart integration, Trade India Integration, Odoo Integration""",
    'summary': 'Common CRM Information, common data for india mart, trade india integration',
    'license': 'OPL-1',
    'depends': ['base', 'crm'],
    'website': 'https://www.speeduplight.com',
    'support': 'apps.speeduplight@gmail.com',
    'data': [
            'security/ir.model.access.csv',
            'views/crm_lead.xml',
            'wizard/wb_generic_msg_wizard.xml',
        ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'images': ['static/description/banner.png']
}

