##############################################################################
#
#    Copyright (C) 2022-Present Speeduplight (<https://speeduplight.com>)
#
##############################################################################
from odoo import models, fields, api, _


class WBGenericMsgWizard(models.TransientModel):
    _name = 'wb.generic.msg.wizard'

    name = fields.Text(string='Description')

    def action_ok(self):
        return {
            'name': _('Leads'),
            'type': 'ir.actions.act_window',
            'res_model': 'crm.lead',
            'view_mode': 'kanban,tree,graph,pivot,form,calendar,activity',
            'domain': [('type', '=', 'opportunity')],
            'context': {'default_type': 'opportunity','search_default_assigned_to_me': 1}
        }
