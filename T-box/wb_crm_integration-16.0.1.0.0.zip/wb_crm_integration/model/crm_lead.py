##############################################################################
#
#    Copyright (C) 2022-Present Speeduplight (<https://speeduplight.com>)
#
##############################################################################
from odoo import api, fields, models


class CRMLead(models.Model):
    _inherit = "crm.lead"

    wb_id = fields.Char(string="RFI ID")
    wb_generated = fields.Integer(string="Generated")
    wb_product_id = fields.Char(string="Product")
    wb_product = fields.Char(string="Product ID")
    wb_product_src = fields.Char(string="Product Source")
    wb_fax = fields.Char(string="Fax")
    wb_inquiry_type = fields.Char(string="Inquiry Type")
    wb_member_since = fields.Char(string="Member Since")
    wb_order_value_min = fields.Integer(string="Order Value Min")
    wb_pref_supp_location = fields.Char(string="Pref Supp. Location")
    wb_qty = fields.Char(string="Quantity")
    wb_sender_uid = fields.Integer(string="Sender ID")
    wb_datetime = fields.Char(string="Receive Datetime")
    wb_mobile = fields.Char(string="Enquiry Mobile")
    wb_email = fields.Char(string="Alt Email")
    wb_call_duration = fields.Char(string="Call Duration")

