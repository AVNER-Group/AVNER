.. _changelog:

Changelog
=========

`16.0.1.1.0`
------------

- Add translations for Ukrainian language.

- Add demo data records.

`16.0.1.0.0`
------------

- Migration from 15.0.


