* Jordi Ballester Alomar <jordi.ballester@forgeflow.com>
* Hizbul Bahar <hizbul25@gmail.com>
* Harald Panten <harald.panten@sygel.es>
* Juany Davila <juany.davila@forgeflow.com>
* Manuel Regidor <manuel.regidor@sygel.es>
