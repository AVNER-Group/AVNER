This module adds a recommended products wizard to current purchase order.

It is based on delivered products to customer locations in a given range of
dates, and allows the purchase manager to quickly know the most sold products
for the current supplier, which results in an easy to use hint to improve
the purchase workflow.

If you want a better mobile usability, the module is ready to use with the
'web_widget_numeric_step' module. Just install it and you will get a better
numeric input experience.
