from . import test_purchase_manual_delivery
