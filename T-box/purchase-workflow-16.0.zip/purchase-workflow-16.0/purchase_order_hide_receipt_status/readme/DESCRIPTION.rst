This module is designed to enhance the user experience by hiding the "receipt_status" field
in purchase order form view and tree view. The purpose is to avoid any confusion that may arise
when 'reception_status' field becomes visible once the 'purchase_reception_status' module is installed.
