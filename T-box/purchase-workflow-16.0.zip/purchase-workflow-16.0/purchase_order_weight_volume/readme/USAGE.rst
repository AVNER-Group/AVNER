To use this module, you need to:

* Go to Purchase settings.
* Enable checkboxes "Display Order Weight in PO" and/or "Display Order Volume in PO".
* Go to Products. Update some products with weight and volume values.
* Go to Purchase.
* Create new RFQ. Add products.
* You will see new column with total line items weight and volume.
* You will see order total weight and volume, tab "Other information".
* From this tab, you can also choose whether to display weight and/or volume info in report.

"Display Order Weight in PO" and "Display Order Volume in PO" can be enabled/disabled
per company.
