* Miquel Raïch <miquel.raich@forgeflow.com>
* Andreas Dian Sukarno Putro <andreasdian777@gmail.com>
* Kitti Upariphutthiphong <kittiu@ecosoft.co.th>
* Eric Antones <eantones@nuobit.com>
* Juany Davila <juany.davila@forgeflow.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Roca
