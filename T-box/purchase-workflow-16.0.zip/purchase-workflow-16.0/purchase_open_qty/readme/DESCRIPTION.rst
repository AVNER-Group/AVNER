This module allows purchase users to identify what are the purchase orders
that currently have quantities pending to invoice or to receive.
