Adds a dashboard for Purchase Orders based on Purchase Order Types.
