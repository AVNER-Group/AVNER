To use this module, you need to:

#. Merge purchase order with required criteria
