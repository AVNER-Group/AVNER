* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
  * Murtaza Mithaiwala <murtaza.m.serpentcs@gmail.com>
  * Quan Nguyen <quan.nhm@komit-consulting.com>
