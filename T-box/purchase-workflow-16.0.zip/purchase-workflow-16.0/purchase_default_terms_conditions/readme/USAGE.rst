To use this module, you need to:

#. Go do Purchase App
#. Create a New Purchase/Quotation Order
