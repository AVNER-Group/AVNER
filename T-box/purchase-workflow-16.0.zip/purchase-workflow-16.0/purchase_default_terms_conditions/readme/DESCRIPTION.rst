This module allows purchase default terms & conditions from Suppler or Company
