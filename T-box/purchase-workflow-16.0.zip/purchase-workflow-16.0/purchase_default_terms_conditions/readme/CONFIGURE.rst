To configure this module, you need to:

#. Go to Purchase Settings
#. Enable Default Terms & Conditions
#. Set Default Terms & Conditions
#. Set Terms & Conditions in Suppler
