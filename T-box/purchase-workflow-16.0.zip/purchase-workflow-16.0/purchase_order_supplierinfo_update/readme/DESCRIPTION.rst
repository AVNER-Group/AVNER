This module extends the functionality of purchase to allow the price
of the supplier-info to be updated automatically for each product of the
a purchase when it is confirmed. This will allow that when a purchase order
is created, the suggested price for those products is the last one purchased.
