To use this module, you need to:

#. Go to *Purchase > Orders > Requests for Quotation* and create a new
   Requests for Quotation with several products.
#. Confirm that quotation and the unit prices defined on the lines will
   be stored in the supplier-info (related to the quotation supplier)
   of the products.
#. By default the suggested price for the products is the one stored in
   supplier-info, so in this way, if you create another quotation with
   the same supplier and the same products, the suggested price for each
   product will be the same price at which the product was last purchased.
