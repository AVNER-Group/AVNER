* Refactor that module to share algorithm with similar module `account_invoice_supplierinfo_update`.
