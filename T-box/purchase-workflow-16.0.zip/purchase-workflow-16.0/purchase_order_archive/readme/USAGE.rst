To archive purchase orders, you need to:

#. Open the tree view of purchase orders.
#. Select a purchase order (in status Locked or Cancelled) you want to archive.
#. Click on Action > Archive. Confirm.
#. The purchase order is now archived.

To unarchive purchase orders, you need to:

#. Open the tree view of purchase orders.
#. In the filter box select the Archived filter. The list of archived purchase orders will be displayed.
#. Select the purchase order (in status Locked or Cancelled) you want to restore to Active.
#. Click on Action > Unarchive.
#. The purchase order is now active.
