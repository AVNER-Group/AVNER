By standard feature, user can gradually create partial invoices, one by one and
in step create invoice the standard call invoice.
This module add ability to create invoices based on the predefined invoice plan,
either all at once, or one by one.
