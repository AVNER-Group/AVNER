#. Create a purchase order and confirm it.
#. Go to page "Other information" and select an option of the "Invoice Method" field.
#. #. If "On ordered quantited" is selected you can bill a purchase even you haven't received the product.
#. #. If "On received quantited" is selected you cannot bill a purchase if you haven't received the product.
