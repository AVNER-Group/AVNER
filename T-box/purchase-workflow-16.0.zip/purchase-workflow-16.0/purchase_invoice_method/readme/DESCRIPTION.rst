This module adds the possibility for users to force the invoice status of the
purchase orders to 'Waiting Bills' so they can create a bill.
Also, you can force an "On ordered quantites" invoice method to "On received quantites".

Example: you can bill a purchase even when you haven't received the product/service.
