Menu option available at Purchase > Orders > Purchase Order Lines.
