* `Open Source Integrators <https://opensourceintegrators.com>`:

  * Daniel Reis <dreis@opensourceintegrators.com>
  * Freni Patel <fpatel@opensourceintegrators.com>
  * Murtaza Mithaiwala <mmithaiwala@opensourceintegrators.com>

  * `Moduon Team <https://moduon.team>`:

    * Eduardo de Miguel <edu@moduon.team>
    * Emilio Pascual <emilio@moduon.team>
    * Rafael Blasco <rblasco@moduon.team>
