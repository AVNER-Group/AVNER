* Chafique Delli <chafique.delli@akretion.com>
* Mourad EL HADJ MIMOUNE <mourad.elhadj.mimoune@akretion.com>
* Hieu, Vo Minh Bao <hieu.vmb@komit-consulting.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Manuel Calero
  * Pedro M. Baeza

* `Via laurea <https://www.vialaurea.com>`__:

  * Darius Žižys
