from . import test_purchase_allowed_product
