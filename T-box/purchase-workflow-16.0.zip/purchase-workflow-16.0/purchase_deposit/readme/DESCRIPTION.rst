This module allow purchase order to register deposit similar to that in sales order
