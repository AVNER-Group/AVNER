* Akim Juillerat <akim.juillerat@camptocamp.com>
* Thomas Nowicki <thomas.nowicki@camptocamp.com>
* François Honoré <francois.honore@acsone.eu>
* Hiep (Nguyen Hoang) <hiepnh@trobz.com>
* Phuc (Tran Thanh) <phuc@trobz.com>
* Duong (Tran Quoc) <duongtq@trobz.com>
* Telmo Santos <telmo.santos@camptocamp.com>
* Jacques-Etienne Baudoux (BCIM) <je@bcim.be>
