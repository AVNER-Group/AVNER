The development of this module has been financially supported by:

* Camptocamp

This module feature was extracted from the original `sale-workflow/sale_by_packaging <https://github.com/oca/sale-workflow/tree/14.0/sale_by_packaging>`_ module.
