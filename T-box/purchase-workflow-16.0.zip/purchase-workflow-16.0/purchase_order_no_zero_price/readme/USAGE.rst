To use:

- Create an RFQ, and add a line with zero price.
- Confirm the RFQ, an error message will prevent that and ask you to enter the missing
  prices.
- A zero subtotal line can still be entered by setting a 100% discount.
