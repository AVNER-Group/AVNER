Prevent zero prices on confirmed POs to help ensure proper Stock Valuation
when receiving the products.

Also supports `purchase_triple_discount` module, if installed.
