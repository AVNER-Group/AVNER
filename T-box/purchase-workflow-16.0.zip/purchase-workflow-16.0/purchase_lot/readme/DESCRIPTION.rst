This module propagate lot from sale orders to purchase orders.
It allows to buy specific lot for an sale order (may be usefull for fully configurable products)
