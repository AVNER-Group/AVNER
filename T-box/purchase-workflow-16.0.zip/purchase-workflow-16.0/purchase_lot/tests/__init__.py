from . import test_purchase_lot
